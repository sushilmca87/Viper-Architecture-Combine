//
//  MyTravelHelperTests.swift
//  MyTravelHelperTests
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import XCTest
@testable import MyTravelHelper
class MyTravelHelperTests: XCTestCase {
    var favDao:FavoriteDao?
    var mockPresenter:MockSearchPresenter!
    var searchTrainService:MockTrainSearchInteractor?
    override func setUp() {
        super.setUp()
        self.favDao = FavoriteDao()
        mockPresenter = MockSearchPresenter()
        searchTrainService = MockTrainSearchInteractor()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    func testOnFavoritesPresenter(){
          // perform Unit test on Favorites Table
           let info = FavoritesStation(sourceAdress: "BelFast", distinationAdress: "Lisburn")
        favDao?.saveStationInfo(stationInfo: info)
        XCTAssertFalse(((favDao?.fetchAllFavoritesStation().isEmpty) == nil), "Data is not inserting in table")
    }
    func testFetchallStations(){
        print("found value")
        let promise = expectation(description: "Status code: 200")
        searchTrainService?.fetchAllStation(completionHandler: { result in
            switch result {
            case .success( _):
                promise.fulfill()
                XCTAssertTrue(self.mockPresenter.fetchedTrainsList, "Apo excuted sucessfull")
            case .failure(let error):
                XCTFail("Status code: \(error)")
            }
        })
        wait(for: [promise], timeout: 30)
    }
    func testFetchStation(){
         let promise = expectation(description: "Status code: 200")
        let sourceCode = "A149"
        searchTrainService?.fetchStation(code: sourceCode, completionHandler: { resulte in
            switch resulte {
            case .success( _):
                promise.fulfill()
                XCTAssertTrue(self.mockPresenter.stationListFetched, "Apo excuted sucessfull")
            case .failure(let error):
                XCTFail("Status code: \(error)")
            }
        })
       wait(for: [promise], timeout: 30)
    }
    func testSorceAndDestination(){
        let promises = expectation(description: "Status Code:200")
        let sourceCode = "BelFast"
        let distination = "Lisburn"
        searchTrainService?.fetchStation(code: "A149", completionHandler: { resulte in
            switch resulte {
            case .success( let trainList):
                self.fetchTrainList(trainList: trainList, sCode: sourceCode, dCode: distination) { result in
                    promises.fulfill()
                    if result {
                        XCTAssertTrue(result, "Successfully fetch train list")
                    }else {
                        XCTAssertTrue(result, "Error while fetching")
                    }
                }
            case .failure(let error):
                promises.fulfill()
                XCTFail("Status code: \(error)")
            }
        })
        wait(for: [promises], timeout: 30)
    }
    func fetchTrainList(trainList:[StationTrain], sCode:String, dCode:String, completionHandler: @escaping (_ result:Bool)->Void){
        searchTrainService?.proceesTrainListforDestinationCheck(trainsList: trainList, sourceStationCode: sCode, destinationStationCode: dCode, completionHandler: { result in
            switch result {
            case .success( _):
                completionHandler(true)
            case .failure(_):
                completionHandler(false)
            }
        })
        
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
   
    }
   
    func testUnitTestingOnFavoritesRealmTable(){
       //searchIntercator.addSearchTrainStationName(sourceAdress: "BelFast1", distinationAdress: "Lisburn1")

    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }

}
