//
//  MockTrainSearchInteractor.swift
//  MyTravelHelperTests
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
@testable import MyTravelHelper
import Combine
class MockTrainSearchInteractor {
    var store = Set<AnyCancellable>()
    var searchProtocol:WebServiceRequestProtocol?
    init() {
        searchProtocol = SearchTrainService()
    }
    func fetchAllStation(completionHandler: @escaping (Result<[Station], Failure>) -> (Void))  {
        searchProtocol?.fetchAllStation().sink(receiveCompletion: { result in
            switch result {
            case .finished:
                print("Finish")
            case .failure(_):
                completionHandler(.failure(Failure.FoundNil))
            }
        }, receiveValue: { stations in
            completionHandler(.success(stations))
        }).store(in: &store)
        
    }
    func fetchStation(code:String, completionHandler: @escaping  (Result<[StationTrain], Failure>) -> Void) {
        searchProtocol?.fetchStation(code: code).sink(receiveCompletion: { completion in
            switch completion {
            case .finished:
                print("Finish")
            case .failure(_):
                completionHandler(.failure(Failure.FoundNil))
            }
        }, receiveValue: { trains in
            completionHandler(.success(trains))
        }).store(in: &store)
    }
    func proceesTrainListforDestinationCheck(trainsList: [StationTrain], sourceStationCode:String, destinationStationCode:String, completionHandler:@escaping (Result<[StationTrain],Failure>)-> Void) {
        searchProtocol?.proceesTrainListforDestinationCheck(trainsList: trainsList, sourceStationCode: sourceStationCode, destinationStationCode: destinationStationCode).sink(receiveCompletion: { completion in
            switch completion {
            case .finished:
                print("Finish")
            case .failure(_):
                completionHandler(.failure(Failure.FoundNil))
            }
        }, receiveValue: { trains in
            completionHandler(.success(trains))
        }).store(in: &store)
    }
}
