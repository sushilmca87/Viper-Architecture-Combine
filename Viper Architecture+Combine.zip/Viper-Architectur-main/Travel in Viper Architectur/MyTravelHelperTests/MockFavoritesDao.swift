//
//  MockFavoritesInteractor.swift
//  MyTravelHelperTests
//
//  Created by Sushil Kumar Singh on 23/01/22.
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
@testable import MyTravelHelper
import RealmSwift
import Realm
protocol MockDaoProtocol {
    func saveStationInfo(stationInfo: FavoritesStation) -> Bool
    func fetchAllFavoritesStation() ->[FavoritesModel]
}

class MockFavoritesDao: MockDaoProtocol {
    var favoritesDao:FavoriteDao?
    init() {
        favoritesDao = FavoriteDao()
    }
    func saveStationInfo(stationInfo: FavoritesStation) -> Bool{
        favoritesDao?.saveStationInfo(stationInfo: stationInfo)
        return (favoritesDao?.fetchAllFavoritesStation().filter({$0.sourceAddress == stationInfo.sourceAdress}).first != nil)
    }
    func fetchAllFavoritesStation() -> [FavoritesModel] {
        return favoritesDao?.fetchAllFavoritesStation() ?? []
    }
    
   
   
}
