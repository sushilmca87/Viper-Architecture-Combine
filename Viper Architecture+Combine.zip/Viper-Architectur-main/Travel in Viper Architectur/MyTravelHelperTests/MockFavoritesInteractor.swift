//
//  MockFavoritesInteractor.swift
//  MyTravelHelperTests
//
//  Created by Sushil Kumar Singh on 24/01/22.
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
@testable import MyTravelHelper
import RealmSwift
import Realm
protocol MocFavoProtocol {
    func saveStationInfo() -> Bool
}
class MockFavoritesInteractor: MocFavoProtocol {
    var favoritesDelegate:FavoritesStationUseCase?
    init() {
        favoritesDelegate = FavoriteInteractor()
    }
    func saveStationInfo() -> Bool{
        FavoriteDao().saveStationInfo(stationInfo: FavoritesStation(sourceAdress: "BelFast", distinationAdress: "Lisburn"))
        let result =  favoritesDelegate?.fetchFavoStation().count ?? 0 > 0
        return result
    }
}
