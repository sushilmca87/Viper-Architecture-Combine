//
//  WebServiceRequestProtocol.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22.
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
import  Combine
protocol WebServiceRequestProtocol {
    func fetchAllStation() -> Future<[Station], Failure>
    func fetchStation(code:String)->Future<[StationTrain], Failure>
    func proceesTrainListforDestinationCheck(trainsList: [StationTrain], sourceStationCode:String, destinationStationCode:String) -> Future<[StationTrain], Failure>
}
