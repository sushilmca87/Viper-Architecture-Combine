//
//  Enviornment.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22.
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
protocol EnvironmentDetails{
    var baseUrl:String {get}
    var subUrl: String {get}
}
enum ServerType : String, CustomDebugStringConvertible{
    case provisionURL =  "Provisional"
    case productionURL = "Production"
    
    var description:String {
        return self.rawValue
    }
    var debugDescription: String {
        return "\(self.rawValue)"
    }
}
struct EnviornmentInfo : EnvironmentDetails  {
    let environment:ServerType
    var baseUrl: String {
        switch environment {
        case .provisionURL:
            return "http://api.irishrail.ie/realtime/realtime.asmx/"
        case .productionURL:
            return "http://api.irishrail.ie/realtime/realtime.asmx/"
        }
    }
    var subUrl: String{
        switch environment {
        case .provisionURL:
            return "http://api.irishrail.ie/realtime/realtime.asmx/"
        case .productionURL:
            return "http://api.irishrail.ie/realtime/realtime.asmx/"
        }
    }
}
