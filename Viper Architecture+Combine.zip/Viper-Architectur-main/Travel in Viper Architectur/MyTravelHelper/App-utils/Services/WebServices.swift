//
//  WebServices.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22.
//  Copyright © 2022 Sample. All rights reserved.
//
import Foundation
import Combine
var store = Set<AnyCancellable>()

class WebServices  {
    typealias Element = Data
    private (set) var enviornment: EnviornmentInfo?
    init(serverType: ServerType) {
        enviornment = EnviornmentInfo(environment: serverType)
    }
    func requestApi(httpApi:WebServiceHTTPApi) -> Future<Element, Never>{
        return Future { [self] promises in
            let loUrl = self.getFullUrl(apiCall: httpApi)
            guard let url = URL(string: loUrl) else  {
                return
            }
            URLSession.shared.dataTaskPublisher(for: url).print("Test:")
                .sink { completion in
                    switch completion{
                    case .finished:
                        print("completed")
                    case .failure(_):
                        break
                    }
                } receiveValue: { (data, response) in
                    print("response1111:\(response)")
                    promises(.success(data))
                }
                .store(in: &store)
        }
    }
}
extension WebServices {
    func getFullUrl(apiCall:HttpApiProtocol) ->String{
        switch apiCall.serverType {
        case .provision:
            return ((self.enviornment?.baseUrl ?? "") + apiCall.path)
        case .production:
            return ((self.enviornment?.baseUrl ?? "") + apiCall.path)
        }
    }
}

