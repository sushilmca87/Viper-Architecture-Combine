//
//  SearchTrainService.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22.
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import Combine
import XMLParsing
enum Failure :Error  {
    case NetworkNotReachable
    case FoundNil
}
final class SearchTrainService : WebServiceRequestProtocol {
    var store = Set<AnyCancellable>()
    init() {
    }
    internal  func fetchAllStation() -> Future<[Station], Failure> {
        return Future { promises in
            let webServices = WebServices(serverType: .productionURL)
            let apiCall = WebServiceHTTPApi.fetchAllStation
            webServices.requestApi(httpApi: apiCall).sink { completion in
                switch completion {
                case .finished:
                    print("Finish")
                case .failure(let error):
                    print("Failed:\(error)")
                    promises(.failure(Failure.FoundNil))
                }
            } receiveValue: { data in
                let station = try? XMLDecoder().decode(Stations.self, from: data)
                promises(.success(station?.stationsList ?? []))
            }.store(in: &self.store)
            
        }
    }
    
    internal func fetchStation(code:String)->Future<[StationTrain], Failure> {
        return Future { promises in
            let webServices = WebServices(serverType: .productionURL)
            let apiCall = WebServiceHTTPApi.fetchStation(sourceCode: code)
            webServices.requestApi(httpApi: apiCall).sink { completion in
                switch completion {
                case .finished:
                    print("Finish")
                case .failure(let error):
                    print("Failed:\(error)")
                    promises(.failure(Failure.FoundNil))
                }
            } receiveValue: { data in
                let xmlData = try? XMLDecoder().decode(StationData.self, from: data)
                guard let list = xmlData?.trainsList else {
                    promises(.success([]))
                    return
                }
                promises(.success(list))
            }.store(in: &self.store)
            
        }
    }
    internal func proceesTrainListforDestinationCheck(trainsList: [StationTrain], sourceStationCode:String, destinationStationCode:String) -> Future<[StationTrain], Failure> {
        return Future {promises in
            let webServices = WebServices(serverType: .productionURL)
            var _trainsList = trainsList
            let today = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy"
            let dateString = formatter.string(from: today)
            let group = DispatchGroup()
            if trainsList.count == 0{
                promises(.success([]))
            } else {
                for index  in 0..<trainsList.count {
                    group.enter()
                    let apiCall = WebServiceHTTPApi.fetchTrainListforDestinationCheck(code:(trainsList[index].trainCode), date: dateString)
                    
                    webServices.requestApi(httpApi: apiCall).sink { completion in
                        switch completion {
                        case .finished:
                            print("Finish")
                        case .failure(let error):
                            print("Failed:\(error)")
                            promises(.failure(Failure.FoundNil))
                        }
                    } receiveValue: { data in
                        if let trainMovements = try? XMLDecoder().decode(TrainMovementsData.self, from: data) {
                            let _movements = trainMovements.trainMovements
                            let sourceIndex = _movements.firstIndex(where: {$0.locationCode.caseInsensitiveCompare(sourceStationCode) == .orderedSame})
                            let destinationIndex = _movements.firstIndex(where: {$0.locationCode.caseInsensitiveCompare(destinationStationCode) == .orderedSame})
                            let desiredStationMoment = _movements.filter{$0.locationCode.caseInsensitiveCompare(destinationStationCode) == .orderedSame}
                            let isDestinationAvailable = desiredStationMoment.count == 1
                            
                            if isDestinationAvailable  && sourceIndex! < destinationIndex! {
                                _trainsList[index].destinationDetails = desiredStationMoment.first
                            }
                        }
                        group.leave()
                    }.store(in: &self.store)
                    group.notify(queue: .main) {
                        promises(.success(_trainsList))
                    }
                }
            }
        }
    }
    
}
