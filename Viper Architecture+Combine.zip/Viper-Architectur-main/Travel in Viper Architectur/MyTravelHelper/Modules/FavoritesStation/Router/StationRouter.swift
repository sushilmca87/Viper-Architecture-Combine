//
//  StationRouter.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit

class StationRouter:NSObject {
        func showCall(viewControler:UIViewController) {
           if let favoView = FavoritesViewBuilder.assembleModule() as? FavoritesViewController, let searchView = viewControler as? SearchTrainViewController {
               searchView.addChild(favoView)
            searchView.view.frame = CGRect(x: 0, y: 100, width: searchView.view.frame.size.width, height: searchView.view.frame.size.height)
            searchView.view.addSubview(favoView.view)
            searchView.didMove(toParent: favoView)
            searchView.view.isHidden = true
           }
       }

}
