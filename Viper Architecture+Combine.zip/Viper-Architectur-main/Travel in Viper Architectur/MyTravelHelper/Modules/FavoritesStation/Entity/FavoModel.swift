//
//  FavoModel.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift
class FavoModel: Entity {

    typealias RealmEntityType = FavoEntity
    dynamic var sourceAddress:String?
    dynamic var distanationAddress:String?
     init() {}
       init(favoEntity:RealmEntityType) {
           self.sourceAddress = favoEntity.sourceAddress
           self.distanationAddress = favoEntity.distanationAddress
          
       }
       var realmObject: FavoEntity {
           return FavoEntity(model: self)
       }
}
