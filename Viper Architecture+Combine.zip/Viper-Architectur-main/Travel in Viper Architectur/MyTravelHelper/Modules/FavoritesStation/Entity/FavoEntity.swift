//
//  FavoEntity.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift
protocol RealmEntity {
    associatedtype ModelType
    var modelObject: ModelType { get }
}
protocol Entity {
    associatedtype RealmEntityType
    var realmObject: RealmEntityType { get }
}
class FavoEntity: Object,RealmEntity {
    typealias ModelType = FavoModel
    dynamic var sourceAddress:String?
    dynamic var distanationAddress:String?
    var modelObject: FavoModel {
        return FavoModel(favoEntity: self)
    }
}
extension FavoEntity {
    convenience init(model: ModelType) {
        self.init()
        self.sourceAddress = model.sourceAddress ?? self.sourceAddress
        self.distanationAddress = model.distanationAddress ?? self.distanationAddress
    }

}
