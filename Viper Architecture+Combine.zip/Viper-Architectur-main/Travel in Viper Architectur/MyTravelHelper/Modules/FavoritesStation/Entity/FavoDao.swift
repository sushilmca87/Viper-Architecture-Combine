//
//  FavoDao.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift


struct FavoriteDao {
    dynamic var sourceAddress:String?
    dynamic var distanationAddress:String?
    public init() {
        
    }
    func saveStationInfo(stationInfo:FavoritesStation){
        let realm = try? Realm()
        let favorites = realm?.objects(FavoritesModel.self).filter("sourceAddress contains[c] %@ && distanationAddress contains[c] %@",stationInfo.sourceAdress,stationInfo.distinationAdress)
        if let value = favorites?.first {
            print("record found value:\(value)")
            self.deleted(object: value)
            self.saveStationInfo(stationInfo: stationInfo)
        }else{
             let favo = FavoritesModel()
             favo.sourceAddress = stationInfo.sourceAdress
             favo.distanationAddress = stationInfo.distinationAdress
             try? realm?.write {
             realm?.add(favo)
          }
        }
    }
    func deleted(object:Object){
        let realm = try! Realm()
        try? realm.write {
            print("deleted word: \(object)")
            realm.delete(object)
        }
    }
    func fetchAllFavoritesStation() ->[FavoritesModel]{
        let realm = try? Realm()
        var models:[FavoritesModel] = []
        let favorites = realm?.objects(FavoritesModel.self)
        favorites?.forEach { (model) in
            models.insert(model, at: 0)
        }
        print("models:\(models.count)")
        return models
    }
}
