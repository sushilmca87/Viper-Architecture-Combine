//
//  FavoritesModel.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift
class FavoritesModel: Object {
   @objc dynamic var sourceAddress:String = ""
   @objc dynamic var distanationAddress:String = ""
}
