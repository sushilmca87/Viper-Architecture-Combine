//
//  FavoritePresenter.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
protocol FavoStationPresentation : ViewPresentation {
    func updateStationView()
}
class FavoritePresenter: NSObject,FavoStationPresentation {
    var interactor:FavoritesStationUseCase?
    weak var view:FavoritesStationView?
    func viewDidLoad() {
       let result =  self.interactor?.fetchFavoStation()
    }
    func viewWillAppear() {}
    func viewWillDisapper() {}
    func updateStationView(){
        print("need to update")
    }
}
extension FavoritePresenter: favoStationIntractorDelegate {
    func updateFavoritesStation(viewModel: FavoritesViewModel) {
        self.view?.updateFavorites(viewModel: viewModel)
    }
}
