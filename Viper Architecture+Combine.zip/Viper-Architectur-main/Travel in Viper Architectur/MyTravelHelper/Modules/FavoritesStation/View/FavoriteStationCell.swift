//
//  FavoriteStationCell.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit

class FavoriteStationCell: UITableViewCell {

     @IBOutlet weak var sourceAddress:UILabel!
     @IBOutlet weak var distinationAdreess:UILabel!
     override func awakeFromNib() {
         super.awakeFromNib()
         // Initialization code
     }
     func configureCell(info:FavoritesStation){
      self.sourceAddress.text = info.sourceAdress
      self.distinationAdreess.text = info.distinationAdress
     }
     override func setSelected(_ selected: Bool, animated: Bool) {
         super.setSelected(selected, animated: animated)
         // Configure the view for the selected state
     }
}
