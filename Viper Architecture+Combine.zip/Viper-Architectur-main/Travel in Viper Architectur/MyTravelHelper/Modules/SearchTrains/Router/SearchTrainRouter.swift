//
//  SearchTrainRouter.swift
//  MyTravelHelper
//
//  Created by Satish on 11/03/19.
//  Copyright © 2019 Sample. All rights reserved.
//

import UIKit
class SearchTrainRouter: PresenterToRouterProtocol {
   
    static func createModule() -> SearchTrainViewController {
        let view = mainstoryboard.instantiateViewController(withIdentifier: "searchTrain") as! SearchTrainViewController
        var presenter: ViewToPresenterProtocol & InteractorToPresenterProtocol = SearchTrainPresenter()
        let interactor = SearchTrainInteractor()
        let router:PresenterToRouterProtocol = SearchTrainRouter()

        view.presenter = presenter
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        interactor.presenter = presenter
        interactor.searchTrainService = SearchTrainService()
        return view
    }
    func createFavoritesModule(viewControler:UIViewController) -> FavoritesViewController {
           if let dialerPadVC = FavoritesViewBuilder.assembleModule() as? FavoritesViewController, let favoritesView = viewControler as? SearchTrainViewController {
                  favoritesView.addChild(dialerPadVC)
                  dialerPadVC.view.frame = CGRect(x: 0, y: 200, width: favoritesView.view.frame.size.width, height: favoritesView.view.frame.size.height - 200)
                  favoritesView.view.addSubview(dialerPadVC.view)
                   dialerPadVC.didMove(toParent: favoritesView)
                 return dialerPadVC
              }
        return FavoritesViewController()
    }

    static var mainstoryboard: UIStoryboard{
        return UIStoryboard(name:"Main",bundle: Bundle.main)
    }
}
