//
//  SearchTrainInteractor.swift
//  MyTravelHelper
//
//  Created by Satish on 11/03/19.
//  Copyright © 2019 Sample. All rights reserved.
//

import Combine
import Foundation
import XMLParsing
import Combine
enum APIUrl {
    case allStation
    case trainMoveMent
    case stationCode
}
class SearchTrainInteractor: PresenterToInteractorProtocol {
    var _sourceStationCode: String = ""
    var _destinationStationCode: String = ""
    var presenter: InteractorToPresenterProtocol?
    var searchTrainService:WebServiceRequestProtocol?
    var store = Set<AnyCancellable>()
    func fetchallStations() {
        searchTrainService?.fetchAllStation()
            .receive(on: DispatchQueue.main)
            .sink { completion in
            switch completion {
            case .finished:
                print("Fiish")
            case .failure(let error):
                print("error:\(error.localizedDescription)")
                self.presenter?.showNoInterNetAvailabilityMessage()
            }
        } receiveValue: { stations in
            self.presenter?.stationListFetched(list: stations)
        }.store(in: &store)
    }
    func addSearchTrainStationName(sourceAdress:String,distinationAdress:String){
        let stationInfo = FavoritesStation(sourceAdress: sourceAdress, distinationAdress: distinationAdress)
        FavoriteDao().saveStationInfo(stationInfo: stationInfo)
    }
    
    func fetchTrainsFromSource(sourceCode: String, destinationCode: String) {
        _sourceStationCode = sourceCode
        _destinationStationCode = destinationCode
        searchTrainService?.fetchStation(code: sourceCode)
            .receive(on: DispatchQueue.main)
            .sink { completion in
            switch completion {
            case .finished:
                print("show finish")
            case .failure(let error):
                print("error:\(error)")
                self.presenter?.showNoTrainAvailbilityFromSource()
            }
        } receiveValue: { stations in
            self.proceesTrainListforDestinationCheck(trainsList: stations)
        }.store(in: &store)
    }
    
    private func proceesTrainListforDestinationCheck(trainsList: [StationTrain]) {
        if Reach().isNetworkReachable() {
            searchTrainService?.proceesTrainListforDestinationCheck(trainsList: trainsList, sourceStationCode: _sourceStationCode, destinationStationCode: _destinationStationCode)
                .receive(on: DispatchQueue.main)
                .sink {completion in
                switch completion {
                case .finished:
                    print("show finish")
                case .failure(let error):
                    print("error:\(error)")
                    self.presenter!.showNoInterNetAvailabilityMessage()
                }
            } receiveValue: { trainsList in
                let sourceToDestinationTrains = trainsList.filter{$0.destinationDetails != nil}
                self.presenter?.fetchedTrainsList(trainsList: sourceToDestinationTrains)
            }.store(in: &store)
        }else {
            self.presenter?.showNoInterNetAvailabilityMessage()
        }
    }
}
